import React from "react";

export default function Home() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>Editor Literario</h1>
      <p>Corrige, mejora y analiza tus textos con inteligencia artificial.</p>
    </div>
  );
}
