import React from "react";
import Head from "next/head";

export default function Home() {
  return (
    <>
      <Head>
        <title>Editor Literario</title>
        <meta name="description" content="Asistente literario con IA para mejorar la escritura y corrección de textos." />
      </Head>
      <main className="flex flex-col items-center justify-center min-h-screen p-5 bg-gray-100">
        <h1 className="text-4xl font-bold text-gray-900">Editor Literario</h1>
        <p className="mt-4 text-lg text-gray-700">
          Corrige, mejora y analiza tus textos con inteligencia artificial.
        </p>
        <button className="mt-6 px-5 py-3 text-white bg-blue-600 rounded-lg hover:bg-blue-700">
          Probar Ahora
        </button>
      </main>
    </>
  );
}
